"""
Redis database and workers.
"""

"""
Helper functions for tasks.
"""
